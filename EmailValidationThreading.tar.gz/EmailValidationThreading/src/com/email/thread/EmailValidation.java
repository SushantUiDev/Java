package com.email.thread;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.Console;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Properties;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;

public class EmailValidation implements Runnable {
	private static Connection connection = null;
	static int t=0;
	 static Logger logger = Logger.getLogger("MyLog");
	static FileHandler fh ;
	{
  
	try {
		fh = new FileHandler("LogInfo.log");
	} catch (SecurityException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}   
	logger.addHandler(fh); 
	SimpleFormatter formatter = new SimpleFormatter();
	fh.setFormatter(formatter);
	}
	public static Properties loadPropertiesFile() throws IOException {
		Properties prop = new Properties();
		InputStream in = new FileInputStream("connection.properties");
		prop.load(in);
		in.close();
		return prop;

	}

	public static Connection getConnection() {
		String excepEmail = null;
		if (connection != null) {
			return connection;
		} else {
			try {
				Properties prop = loadPropertiesFile();
				String driver = prop.getProperty("MSSQL_driver");
				String dbName = prop.getProperty("MSSQL_dbname");

				String port = prop.getProperty("MSSQL_port");

				String url = prop.getProperty("MSSQL_url");

				String username = prop.getProperty("MSSQL_username");
				excepEmail = prop.getProperty("MSSQL_exepEmail");
				String password = prop.getProperty("MSSQL_password");
				String selectQuery = prop.getProperty("MSSQL_SelectQery");
				// selectQuery="select * from emailvalidationbatch1 where status

				Class.forName(driver);
				connection = DriverManager.getConnection(
						url + ":" + port + ";database=" + dbName + ";user=" + username + ";password=" + password);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return connection;
	}

	private static int hear(BufferedReader in) throws IOException {
		// System.out.println("hear method");
		String line = null;
		int res = 0;

		while ((line = in.readLine()) != null) {
			String pfx = line.substring(0, 3);
			try {
				res = Integer.parseInt(pfx);
			} catch (Exception ex) {
				res = -1;
			}
			if (line.charAt(3) != '-')
				break;
		}

		return res;
	}

	private static void say(BufferedWriter wr, String text) throws IOException {
		// System.out.println("say method");
		wr.write(text + "\r\n");
		wr.flush();

		return;
	}

	private static ArrayList getMX(String hostName, String address)
			throws NamingException, SQLException, ClassNotFoundException, IOException {
		PreparedStatement pstatement = null;
		connection = EmailValidation.getConnection();
	//	System.out.println("Domain: " + hostName);
		logger.info(hostName);
		// Perform a DNS lookup for MX records in the domain
		Hashtable env = new Hashtable();
		env.put("java.naming.factory.initial", "com.sun.jndi.dns.DnsContextFactory");
		DirContext ictx = new InitialDirContext(env);
		Attributes attrs = ictx.getAttributes(hostName, new String[] { "MX" });
		Attribute attr = attrs.get("MX");

		// if we don't have an MX record, try the machine itself
		if ((attr == null) || (attr.size() == 0)) {

			attrs = ictx.getAttributes(hostName, new String[] { "A" });
			attr = attrs.get("A");

			pstatement = connection
					.prepareStatement("update emailvalidationbatch1 set status1=0 where email='" + address + "'");

			pstatement.executeUpdate();
			if (attr == null) {

				throw new NamingException("No match for name '" + hostName + "'");
			}
		} else {

			pstatement = connection
					.prepareStatement("update emailvalidationbatch1 set status1=1 where email='" + address + "'");

			pstatement.executeUpdate();
		}

		// Huzzah! we have machines to try. Return them as an array list
		// NOTE: We SHOULD take the preference into account to be absolutely
		// correct. This is left as an exercise for anyone who cares.
		ArrayList res = new ArrayList();
		NamingEnumeration en = attr.getAll();

		while (en.hasMore()) {
			String mailhost;
			String x = (String) en.next();
			// System.out.println("=="+x);
			String f[] = x.split(" ");
			if (f.length == 1)
				mailhost = f[0];
			else if (f[1].endsWith("."))
				mailhost = f[1].substring(0, (f[1].length() - 1));
			else
				mailhost = f[1];

			res.add(mailhost);
		}
		return res;
	}

	@SuppressWarnings("resource")
	public static boolean isAddressValid(String address) throws SQLException, ClassNotFoundException, IOException {
		boolean emailFlag = emailValid(address);
		// System.out.println(address+" : "+emailFlag);
		if (emailFlag) {
			// Find the separator for the domain name
			int pos = address.indexOf('@');

			// If the address does not contain an '@', it's not valid
			if (pos == -1)
				return false;

			// Isolate the domain/machine name and get a list of mail exchangers
			String domain = address.substring(++pos);

			ArrayList mxList = null;
			try {
				mxList = getMX(domain, address);
				//System.out.println("MX Records: " + mxList);
				logger.info(mxList.toString());
			} catch (NamingException ex) {
				PreparedStatement pstatement = null;
				connection = EmailValidation.getConnection();
				Properties prop = loadPropertiesFile();
				pstatement = connection
						.prepareStatement("update emailvalidationbatch1 set status1=0 where email='" + address + "'");

				pstatement.executeUpdate();
				return false;
			}

			// Just because we can send mail to the domain, doesn't mean that
			// the
			// address is valid, but if we can't, it's a sure sign that it isn't
			if (mxList.size() == 0)
				return false;

			// Now, do the SMTP validation, try each mail exchanger until we get
			// a positive acceptance. It *MAY* be possible for one MX to allow
			// a message [store and forwarder for example] and another [like
			// the actual mail server] to reject it. This is why we REALLY ought
			// to take the preference into account.
			for (int mx = 0; mx < mxList.size(); mx++) {
				boolean valid = false;
				try {
					int res;
					Socket skt = new Socket((String) mxList.get(mx), 25);
					BufferedReader rdr = new BufferedReader(new InputStreamReader(skt.getInputStream()));
					BufferedWriter wtr = new BufferedWriter(new OutputStreamWriter(skt.getOutputStream()));

					res = hear(rdr);
					if (res != 220)
						throw new Exception("Invalid header");
					say(wtr, "EHLO inspironit");

					res = hear(rdr);
					if (res != 250)
						throw new Exception("Not ESMTP");

					// validate the sender address
					say(wtr, "MAIL FROM: <ravinder.r@inspironit.com>");
					res = hear(rdr);
					if (res != 250)
						throw new Exception("Sender rejected");

					say(wtr, "RCPT TO: <" + address + ">");
					res = hear(rdr);

					// be polite
					say(wtr, "RSET");
					hear(rdr);
					say(wtr, "QUIT");
					hear(rdr);
					if (res != 250)
						throw new Exception("Address is not valid!");

					valid = true;
					rdr.close();
					wtr.close();
					skt.close();
				} catch (Exception ex) {
					// Do nothing but try next host
				} finally {
					if (valid)
						return true;
				}
			}
			return false;
		} else {
			PreparedStatement pstatement = null;
			connection = EmailValidation.getConnection();
			Properties prop = loadPropertiesFile();
			pstatement = connection
					.prepareStatement("update emailvalidationbatch1 set status1=0 where email='" + address + "'");

			pstatement.executeUpdate();
			return false;
		}
	}

	public static boolean emailValid(String address) {
		String regex2 = "^[a-zA-Z0-9_!#$%&’*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$";
		Pattern pattern = Pattern.compile(regex2);
		Matcher matcher = pattern.matcher(address);
		return matcher.matches();

	}
	
	public static void updateMail() throws SecurityException, IOException, SQLException {
		//Lock lock = new ReentrantLock();
		//Logger logger = Logger.getLogger("MyLog");
		//FileHandler fh;
		//lock.lock();
		/*fh = new FileHandler("EmailLog.log");
		logger.addHandler(fh);
		SimpleFormatter formatter = new SimpleFormatter();
		fh.setFormatter(formatter);*/
		boolean append=true;
		try {
			CallableStatement stmt=null;
			Properties prop = loadPropertiesFile();
		//	String selectQuery = prop.getProperty("MSSQL_SelectQery");
			String selectQuery = "{ call sp_selectemail}";
			
			connection = EmailValidation.getConnection();
			//connection.setAutoCommit(false);
			//	Statement statement = connection.createStatement();
			//	statement.execute("BEGIN TRANSACTION");
			
			PreparedStatement pstatement = null;
			
			 stmt=connection.prepareCall(selectQuery);  
			stmt.execute();
			
			/* {

                 Statement st = connection.createStatement();

                 st.execute("COMMIT");

           }*/
			//connection.commit();
			
			int i=0;
			ResultSet resultSet = stmt.getResultSet();
			
			while (resultSet.next()) {
				String name = resultSet.getString("email");
				i++;
				//System.out.println("Email: "+name);
				
				logger.info(name);
				boolean str = isAddressValid(name);
				//System.out.println(name + " is valid? " + str);
				logger.info(name + " is valid? " + str);
				if (str) {
					pstatement = connection.prepareStatement("insert into validemail_tb values(?,?)");
					pstatement.setString(1, name);
					pstatement.setInt(2, 1);
					pstatement.executeUpdate();
					// update master table record status to 1
					pstatement = connection.prepareStatement(
							"update emailvalidationbatch1 set status=1 where id=" + resultSet.getString("id"));
					pstatement.executeUpdate();

					// update emailvalidationbatch1 set status=1 where
					// id=rs.getString("id");

				} else {

					pstatement = connection.prepareStatement("insert into invalidemail_tb values(?,?)");
					pstatement.setString(1, name);
					pstatement.setInt(2, -1);
					pstatement.executeUpdate();
					// update master table record status to 1
					pstatement = connection.prepareStatement(
							"update emailvalidationbatch1 set status=1 where id=" + resultSet.getString("id"));
					pstatement.executeUpdate();

					// update emailvalidationbatch1 set status=1 where
					// id=rs.getString("id");
				}
				//statement.execute("COMMIT");
			}
			
		
			if(i!=0){
			//run thread multiple time
		new Thread(thread1).start();
			}
		} catch (Exception e) {
			//connection.rollback();
			//fh = new FileHandler("MyLogFile.log");
			logger.addHandler(fh);
			// formatter = new SimpleFormatter();
			//fh.setFormatter(formatter);
			logger.info(e.getMessage());
		}
	
	}

	
	public void run() {
		 try {			
			try {
				EmailValidation.updateMail();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (SecurityException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	 }
	

	static EmailValidation thread1 = new EmailValidation();
	public static void main(String[] args) throws IOException, SQLException {
		Properties prop = loadPropertiesFile();
		String num = prop.getProperty("MSSQL_NoOfThread");
		int threadSize = Integer.parseInt(num);
		//System.out.println(n);
		Thread[] threads = new Thread[threadSize];
		for(int i=0;i<threads.length;i++){
			threads[i] = new Thread(thread1);			
			System.out.println(threads[i]);
			logger.info(threads[i].getName());
			threads[i].start();	
			}	
		/*Executor executor = Executors.newSingleThreadExecutor();
		for (int i = 0; i < threads.length; i++) {
		      executor.execute(new Runnable() {
		         public void run() {
		           EmailValidation.updateMail();
		         }
		     });
		 }*/
		
	}

}
